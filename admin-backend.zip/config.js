// export const mail_backend_url = process.env.MAIL_BACKEND_URL || ''
// export const mail_backend_url = 'http://10.147.21.248:6010' || ''
export const frontend_url = process.env.FE_URL || ''
export const backend_url = process.env.BE_URL || ''